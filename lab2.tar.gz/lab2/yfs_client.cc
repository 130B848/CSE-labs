// yfs client.  implements FS operations using extent and lock server
#include "yfs_client.h"
#include "extent_client.h"
#include <sstream>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

yfs_client::yfs_client()
{
    ec = new extent_client();

}

yfs_client::yfs_client(std::string extent_dst, std::string lock_dst)
{
    ec = new extent_client();
    if (ec->put(1, "") != extent_protocol::OK)
        printf("error init root dir\n"); // XYB: init root dir
}

yfs_client::inum
yfs_client::n2i(std::string n)
{
    std::istringstream ist(n);
    unsigned long long finum;
    ist >> finum;
    return finum;
}

std::string
yfs_client::filename(inum inum)
{
    std::ostringstream ost;
    ost << inum;
    return ost.str();
}

bool
yfs_client::isfile(inum inum)
{
    extent_protocol::attr a;

    if (ec->getattr(inum, a) != extent_protocol::OK) {
        printf("error getting attr\n");
        return false;
    }

    if (a.type == extent_protocol::T_FILE) {
        printf("isfile: %lld is a file\n", inum);
        return true;
    }
    printf("isfile: %lld is a dir or a symbol link\n", inum);
    return false;
}

bool
yfs_client::isdir(inum inum)
{
    extent_protocol::attr a;

    if (ec->getattr(inum, a) != extent_protocol::OK) {
        printf("error getting attr\n");
        return false;
    }

    if (a.type == extent_protocol::T_DIR) {
        printf("isfile: %lld is a dir\n", inum);
        return true;
    }
    printf("isfile: %lld is a file or a symbol link\n", inum);
    return false;
}

/** Your code here for Lab...
 * You may need to add routines such as
 * readlink, issymlink here to implement symbolic link.
 * https://fossies.org/dox/fuse-2.9.7/structfuse__lowlevel__ops.html
 * */

// ino	the inode number
// link	the contents of the symbolic link
int
yfs_client::readlink(inum ino, std::string &link)
{
    int r = OK;

    if (ec->get(ino, link) != extent_protocol::OK) {
        r = IOERR;
        return r;
    }

    return r;
}


// link	the contents of the symbolic link
// parent	inode number of the parent directory
// name	to create
int
yfs_client::symlink(inum parent, const char *link, const char *name,
        inum &ino_out)
{
    int r = OK;

    std::string buf;
    if (ec->get(parent, buf) != extent_protocol::OK) {
        r = NOENT;
        return r;
    }

    if (createhelper(parent, name, 0, ino_out,
                    extent_protocol::T_SYMLINK) != OK) {
          r = IOERR;
          return r;
    }

    // if (ec->get(ino_out, buf) != extent_protocol::OK) {
    //     r = IOERR;
    //     return r;
    // }
    // buf = link;
    if (ec->put(ino_out, link) != extent_protocol::OK) {
        r = IOERR;
        return r;
    }

    return r;
}

int
yfs_client::getfile(inum inum, fileinfo &fin)
{
    int r = OK;

    printf("getfile %016llx\n", inum);
    extent_protocol::attr a;
    if (ec->getattr(inum, a) != extent_protocol::OK) {
        r = IOERR;
        goto release;
    }

    fin.atime = a.atime;
    fin.mtime = a.mtime;
    fin.ctime = a.ctime;
    fin.size = a.size;
    printf("getfile %016llx -> sz %llu\n", inum, fin.size);

release:
    return r;
}

int
yfs_client::getdir(inum inum, dirinfo &din)
{
    int r = OK;

    printf("getdir %016llx\n", inum);
    extent_protocol::attr a;
    if (ec->getattr(inum, a) != extent_protocol::OK) {
        r = IOERR;
        goto release;
    }
    din.atime = a.atime;
    din.mtime = a.mtime;
    din.ctime = a.ctime;

release:
    return r;
}


#define EXT_RPC(xx) do { \
    if ((xx) != extent_protocol::OK) { \
        printf("EXT_RPC Error: %s:%d \n", __FILE__, __LINE__); \
        r = IOERR; \
        goto release; \
    } \
} while (0)

// Only support set size of attr
int
yfs_client::setattr(inum ino, size_t size)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: get the content of inode ino, and modify its content
     * according to the size (<, =, or >) content length.
     */
    extent_protocol::attr a;
    if (ec->getattr(ino, a) != extent_protocol::OK) {
       r = IOERR;
       return r;
    }

    std::string buf;
    if (ec->get(ino, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }
    buf.resize(size);
    if (ec->put(ino, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    return r;
}

int
yfs_client::createhelper(inum parent, const char * name, mode_t mode,
          inum &ino_out, int type)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: lookup is what you need to check if file exist;
     * after create file or dir, you must remember to modify the parent infomation.
     */
    if (!isdir(parent)) {
      r = IOERR;
      return r;
    }

    bool found = false;
    if (lookup(parent, name, found, ino_out) == OK) {
      r = EXIST;
      return r;
    }

    if (ec->create(type, ino_out) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    std::string buf;
    if (ec->get(parent, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }
    buf += "//" + std::string(name) + "/" + filename(ino_out);
    if (ec->put(parent, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    return r;
}

int
yfs_client::create(inum parent, const char *name, mode_t mode, inum &ino_out)
{
    return createhelper(parent, name, mode, ino_out, extent_protocol::T_FILE);
}

int
yfs_client::mkdir(inum parent, const char *name, mode_t mode, inum &ino_out)
{
    return createhelper(parent, name, mode, ino_out, extent_protocol::T_DIR);
}

int
yfs_client::lookup(inum parent, const char *name, bool &found, inum &ino_out)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: lookup file from parent dir according to name;
     * you should design the format of directory content.
     */
    std::string buf;
    if (ec->get(parent, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    std::string filename("//");
    filename = filename + name + "/";
    if (buf.empty()) {
      found = false;
      r = NOENT;
      return r;
    } else {
      std::size_t start = buf.find(filename);
      std::size_t end;
      if (start != std::string::npos) {
        found = true;
        start += filename.size();
        end = buf.find_first_of('/', start);
        if (end != std::string::npos) {
          ino_out = n2i(buf.substr(start, end - start));
        } else {
          ino_out = n2i(buf.substr(start));
        }
        return r;
      } else {
        found = false;
        r = NOENT;
        return r;
      }
    }

    return r;
}

int
yfs_client::readdir(inum dir, std::list<dirent> &list)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: you should parse the dirctory content using your defined format,
     * and push the dirents to the list.
     */
    if (!isdir(dir)) {
      r = IOERR;
      return r;
    }

    std::string buf;
    if (ec->get(dir, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

     if (buf.empty()) {
       r = NOENT;
       return r;
     } else {
       std::size_t pos;
       struct dirent tmp;
       while (!buf.empty()) {
         buf = buf.substr(2);

         pos = buf.find_first_of('/');
         tmp.name = buf.substr(0, pos);
         buf = buf.substr(pos + 1);

         pos = buf.find_first_of('/');
         if (pos == std::string::npos) {
           tmp.inum = n2i(buf);
           list.push_back(tmp);
           return r;
         } else {
           tmp.inum = n2i(buf.substr(0, pos));
           buf = buf.substr(pos);
           list.push_back(tmp);
         }
       }
     }

     return r;
}

int
yfs_client::read(inum ino, size_t size, off_t off, std::string &data)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: read using ec->get().
     */
    std::string buf;
    if (ec->get(ino, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    if ((size_t)off < buf.size()) {
      data = buf.substr(off, size);
    } else {
      data = "";
    }

    return r;
}

int
yfs_client::write(inum ino, size_t size, off_t off, const char *data,
        size_t &bytes_written)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: write using ec->put().
     * when off > length of original file, fill the holes with '\0'.
     */
    std::string buf;
    if (ec->get(ino, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    std::string input(data, size);
    bytes_written = size;
    // if size == 0 but off == original size, replace() still throw exception
    if ((size_t)(off + size) >= buf.size()) {
      bytes_written = off - buf.size() + size;
      buf.resize(off + size);
    }
    buf.replace(off, size, input);
    if (ec->put(ino, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    return r;
}

int yfs_client::unlink(inum parent, const char *name)
{
    int r = OK;

    /*
     * your lab2 code goes here.
     * note: you should remove the file using ec->remove,
     * and update the parent directory content.
     */
    inum ino;
    bool found = false;
    if (lookup(parent, name, found, ino) != OK) {
      r = IOERR;
      return r;
    }
    if (!found) {
      r = NOENT;
      return r;
    }

    std::string buf;
    std::string rm = "//" + std::string(name) + "/" + filename(ino);
    if (ec->get(parent, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }
    buf.erase(buf.find(rm), rm.size());
    if (ec->put(parent, buf) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    if (ec->remove(ino) != extent_protocol::OK) {
      r = IOERR;
      return r;
    }

    return r;
}
