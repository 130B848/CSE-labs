#include "inode_manager.h"

// disk layer -----------------------------------------

disk::disk()
{
  bzero(blocks, sizeof(blocks));
}

void
disk::read_block(blockid_t id, char *buf)
{
  /*
   *your lab1 code goes here.
   *if id is smaller than 0 or larger than BLOCK_NUM
   *or buf is null, just return.
   *put the content of target block into buf.
   *hint: use memcpy
  */
  if (id < BLOCK_NUM && buf) {
    memcpy(buf, blocks[id], BLOCK_SIZE);
  }
}

void
disk::write_block(blockid_t id, const char *buf)
{
  /*
   *your lab1 code goes here.
   *hint: just like read_block
  */
  if (id < BLOCK_NUM && buf) {
    memcpy(blocks[id], buf, BLOCK_SIZE);
  }
}

// block layer -----------------------------------------
#define OFFSET(i) ((i % BPB) >> 3)
#define MASK(i) (1 << (7 - (i % 8)))

// Allocate a free disk block.
blockid_t
block_manager::alloc_block()
{
  /*
   * your lab1 code goes here.
   * note: you should mark the corresponding bit in block bitmap when alloc.
   * you need to think about which block you can start to be allocated.

   *hint: use macro IBLOCK and BBLOCK.
          use bit operation.
          remind yourself of the layout of disk.
   */
   char buf[BLOCK_SIZE];

   for (uint32_t i = IBLOCK(sb.ninodes, sb.nblocks) + 1; i < sb.nblocks; i++) {
     d->read_block(BBLOCK(i), buf);
     if (!((int)buf[OFFSET(i)] & MASK(i))) {
       buf[OFFSET(i)] |= MASK(i);
       d->write_block(BBLOCK(i), buf);
       return i;
     }
   }

   fprintf(stderr, "\tbm: alloc_block failed.\n");
   return 0;
}

void
block_manager::free_block(uint32_t id)
{
  /*
   * your lab1 code goes here.
   * note: you should unmark the corresponding bit in the block bitmap when free.
   */
   char buf[BLOCK_SIZE];

   if (id > IBLOCK(sb.ninodes, sb.nblocks) && id < sb.nblocks) {
     d->read_block(BBLOCK(id), buf);
     if (!((int)buf[OFFSET(id)] & MASK(id))) {
       buf[OFFSET(id)] &= ~MASK(id);
       d->write_block(BBLOCK(id), buf);
     }
   }
}

// The layout of disk should be like this:
// |<-sb->|<-free block bitmap->|<-inode table->|<-data->|
block_manager::block_manager()
{
  d = new disk();

  // format the disk
  sb.size = BLOCK_SIZE * BLOCK_NUM;
  sb.nblocks = BLOCK_NUM;
  sb.ninodes = INODE_NUM;

}

void
block_manager::read_block(uint32_t id, char *buf)
{
  d->read_block(id, buf);
}

void
block_manager::write_block(uint32_t id, const char *buf)
{
  d->write_block(id, buf);
}

// inode layer -----------------------------------------

inode_manager::inode_manager()
{
  bm = new block_manager();
  uint32_t root_dir = alloc_inode(extent_protocol::T_DIR);
  if (root_dir != 1) {
    printf("\tim: error! alloc first inode %d, should be 1\n", root_dir);
    exit(0);
  }
}

/* Create a new file.
 * Return its inum. */
uint32_t
inode_manager::alloc_inode(uint32_t type)
{
  /*
   * your lab1 code goes here.
   * note: the normal inode block should begin from the 2nd inode block.
   * the 1st is used for root_dir, see inode_manager::inode_manager().

   * if you get some heap memory, do not forget to free it.
   */
   struct inode *ino_disk;
   uint32_t inum;

   for (inum = 1; inum < INODE_NUM; inum++) {
     ino_disk = get_inode(inum);
     if (!ino_disk) {
       ino_disk = new inode_t;

       ino_disk->type = type;
       ino_disk->size = 0;
       ino_disk->ctime = ino_disk->mtime = ino_disk->atime = (unsigned int)time(NULL);
       put_inode(inum, ino_disk);

       free(ino_disk);
       return inum;
     } else {
       free(ino_disk);
     }
   }
   fprintf(stderr, "\tim alloc_inode failed.\n");
   return 0;
}

void
inode_manager::free_inode(uint32_t inum)
{
  /*
   * your lab1 code goes here.
   * note: you need to check if the inode is already a freed one;
   * if not, clear it, and remember to write back to disk.
   * do not forget to free memory if necessary.
   */
   struct inode *ino_disk;

   ino_disk = get_inode(inum);
   if (ino_disk && (ino_disk->type == 1 || ino_disk->type == 2)) {
     bzero(ino_disk, sizeof(struct inode));
     put_inode(inum, ino_disk);
     free(ino_disk);
   } else {
     fprintf(stderr, "\tim: free_inode failed.\n");
   }
}


/* Return an inode structure by inum, NULL otherwise.
 * Caller should release the memory. */
struct inode*
inode_manager::get_inode(uint32_t inum)
{
  struct inode *ino, *ino_disk;
  char buf[BLOCK_SIZE];

  // printf("\tim: get_inode %d\n", inum);

  if (inum < 0 || inum >= INODE_NUM) {
    printf("\tim: inum out of range\n");
    return NULL;
  }

  bm->read_block(IBLOCK(inum, bm->sb.nblocks), buf);
  // printf("%s:%d\n", __FILE__, __LINE__);

  ino_disk = (struct inode*)buf + inum%IPB;
  if (ino_disk->type == 0) {
    printf("\tim: inode not exist\n");
    return NULL;
  }

  ino = (struct inode*)malloc(sizeof(struct inode));
  *ino = *ino_disk;

  return ino;
}

void
inode_manager::put_inode(uint32_t inum, struct inode *ino)
{
  char buf[BLOCK_SIZE];
  struct inode *ino_disk;

  // printf("\tim: put_inode %d\n", inum);
  if (ino == NULL)
    return;

  bm->read_block(IBLOCK(inum, bm->sb.nblocks), buf);
  ino_disk = (struct inode*)buf + inum%IPB;
  *ino_disk = *ino;
  bm->write_block(IBLOCK(inum, bm->sb.nblocks), buf);
}

#define MIN(a,b) ((a)<(b) ? (a) : (b))

/* Get all the data of a file by inum.
 * Return alloced data, should be freed by caller. */
void
inode_manager::read_file(uint32_t inum, char **buf_out, int *size)
{
  /*
   * your lab1 code goes here.
   * note: read blocks related to inode number inum,
   * and copy them to buf_out
   */
   struct inode *ino_disk = get_inode(inum);
   uint32_t read_num, i;
   blockid_t *indir_blocks;

   if (ino_disk) {
     if (!ino_disk->type) {
       free(ino_disk);
       return;
     }

     read_num = (uint32_t)ceil((double)ino_disk->size / BLOCK_SIZE);
     *buf_out = (char *)malloc(read_num * BLOCK_SIZE * sizeof(char));
     *size = ino_disk->size;

     if (read_num <= NDIRECT) {
       for (i = 0; i < read_num; i++) {
         bm->read_block(ino_disk->blocks[i], *buf_out + i * BLOCK_SIZE);
       }
     } else {
       for (i = 0; i < NDIRECT; i++) {
         bm->read_block(ino_disk->blocks[i], *buf_out + i * BLOCK_SIZE);
       }

       indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
       bm->read_block(ino_disk->blocks[NDIRECT], (char *)indir_blocks);
       for (i = 0; i < read_num - NDIRECT; i++) {
         bm->read_block(indir_blocks[i], *buf_out + (i + NDIRECT) * BLOCK_SIZE);
       }
       free(indir_blocks);
     }
     free(ino_disk);
   } else {
     fprintf(stderr, "\tim: read_file failed.\n");
   }
}

/* alloc/free blocks if needed */
void
inode_manager::write_file(uint32_t inum, const char *buf, int size)
{
  /*
   * your lab1 code goes here.
   * note: write buf to blocks of inode inum.
   * you need to consider the situation when the size of buf
   * is larger or smaller than the size of original inode.
   * you should free some blocks if necessary.
   */
   struct inode *ino_disk = get_inode(inum);
   uint32_t old_num, new_num, i;
   blockid_t *indir_blocks;

   if (ino_disk) {
     if (!ino_disk->type) {
       free(ino_disk);
       return;
     }

     old_num = (uint32_t)ceil((double)ino_disk->size / BLOCK_SIZE);
     new_num = (uint32_t)ceil((double)size / BLOCK_SIZE);

     if (old_num >= new_num) {
       if (old_num <= NDIRECT) {
         for (i = 0; i < new_num; i++) {
           bm->write_block(ino_disk->blocks[i], buf + i * BLOCK_SIZE);
         }
         for (; i < old_num; i++) {
           bm->free_block(ino_disk->blocks[i]);
         }
       } else {
         if (new_num <= NDIRECT) {
           for (i = 0; i < new_num; i++) {
             bm->write_block(ino_disk->blocks[i], buf + i * BLOCK_SIZE);
           }
           for (; i < NDIRECT; i++) {
             bm->free_block(ino_disk->blocks[i]);
           }

           indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
           bm->read_block(ino_disk->blocks[NDIRECT], (char *)indir_blocks);
           for (i = 0; i < old_num - NDIRECT; i++) {
             bm->free_block(indir_blocks[i]);
           }
           bm->free_block(ino_disk->blocks[NDIRECT]);
           free(indir_blocks);
         } else {
           for (i = 0; i < NDIRECT; i++) {
             bm->write_block(ino_disk->blocks[i], buf + i * BLOCK_SIZE);
           }

           indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
           bm->read_block(ino_disk->blocks[NDIRECT], (char *)indir_blocks);
           for (i = 0; i < new_num - NDIRECT; i++) {
             bm->write_block(indir_blocks[i], buf + (i + NDIRECT) * BLOCK_SIZE);
           }
           for (; i < old_num - NDIRECT; i++) {
             bm->free_block(indir_blocks[i]);
           }
           free(indir_blocks);
         }
       }
     } else {
       if (old_num <= NDIRECT) {
         if (new_num <= NDIRECT) {
           for (i = old_num; i < new_num; i++) {
             ino_disk->blocks[i] = bm->alloc_block();
           }
           for (i = 0; i < new_num; i++) {
             bm->write_block(ino_disk->blocks[i], buf + i * BLOCK_SIZE);
           }
         } else {
           for (i = 0; i < NDIRECT; i++) {
             ino_disk->blocks[i] = bm->alloc_block();
           }

           indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
           ino_disk->blocks[NDIRECT] = bm->alloc_block();
           for (i = 0; i < new_num - NDIRECT; i++) {
             indir_blocks[i] = bm->alloc_block();
           }

           bm->write_block(ino_disk->blocks[NDIRECT], (char *)indir_blocks);
           for (i = 0; i < NDIRECT; i++) {
             bm->write_block(ino_disk->blocks[i], buf + i * BLOCK_SIZE);
           }
           for (i = 0; i < new_num - NDIRECT; i++) {
             bm->write_block(indir_blocks[i], buf + (i + NDIRECT) * BLOCK_SIZE);
           }
           free(indir_blocks);
         }
       } else {
         indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
         ino_disk->blocks[NDIRECT] = bm->alloc_block();
         for (i = old_num - NDIRECT; i < new_num - NDIRECT; i++) {
           indir_blocks[i] = bm->alloc_block();
         }

         for (i = 0; i < NDIRECT; i++) {
           ino_disk->blocks[i] = bm->alloc_block();
         }
         for (i = 0; i < new_num - NDIRECT; i++) {
           bm->write_block(indir_blocks[i], buf + (i + NDIRECT) * BLOCK_SIZE);
         }
         free(indir_blocks);
       }
     }
     ino_disk->size = size;
     ino_disk->ctime = ino_disk->mtime = ino_disk->atime = time(NULL);
     put_inode(inum, ino_disk);
     free(ino_disk);
   } else {
     fprintf(stderr, "\tim: write_file failed.\n");
   }
}

void
inode_manager::getattr(uint32_t inum, extent_protocol::attr &a)
{
  /*
   * your lab1 code goes here.
   * note: get the attributes of inode inum.
   * you can refer to "struct attr" in extent_protocol.h
   */
   struct inode *ino_disk = get_inode(inum);
   if (ino_disk) {
     a.type = ino_disk->type;
     a.atime = ino_disk->atime;
     a.mtime = ino_disk->mtime;
     a.ctime = ino_disk->ctime;
     a.size = ino_disk->size;
   } else {
     fprintf(stderr, "/tim: getattr failed.\n");
   }
}

void
inode_manager::remove_file(uint32_t inum)
{
  /*
   * your lab1 code goes here
   * note: you need to consider about both the data block and inode of the file
   * do not forget to free memory if necessary.
   */
   struct inode *ino_disk = get_inode(inum);
   uint32_t rm_num, i;
   blockid_t *indir_blocks;

   if (ino_disk) {
     rm_num = (uint32_t)ceil((double)ino_disk->size / BLOCK_SIZE);
     if (rm_num <= NDIRECT) {
       free_inode(inum);
     } else {
       indir_blocks = (blockid_t *)malloc(BLOCK_SIZE);
       bm->read_block(ino_disk->blocks[NDIRECT], (char *)indir_blocks);
       for (i = 0; i < rm_num - NDIRECT; i++) {
         bm->free_block(indir_blocks[i]);
       }
     }
     free(ino_disk);
   } else {
     fprintf(stderr, "\tim: remove_file failed.\n");
   }
}
